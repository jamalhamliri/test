[pytest]
DJANGO_SETTINGS_MODULE = BolgUser.settings