from django.shortcuts import render, redirect, get_object_or_404


from app.forms import *
from app.models import *
from app import models


# Create your views here.
def promotion(request):
    promotion = models.Promotion.objects.all()
    return render(request, 'promotion/promotion.html', {'promotion': promotion})
def add_promotion(request):
    form = AddPro()
    if request.method == 'POST':
        form = AddPro(request.POST)
        print(request.POST)
        if form.is_valid():
            promotion = form.save(commit=False)

            promotion.save()
            return redirect('promotion')
    ctx = {
        "form": form,
    }
    return render(request, 'promotion/add.html',ctx)
def delete_promotion(request,pro_id):
    promotion = get_object_or_404(Promotion, id=pro_id)
    delete_form = DeletePro()
    if request.method == 'POST':
        delete_form = DeletePro(request.POST)
        if delete_form.is_valid():
            promotion.delete()
            return redirect('promotion')
    context = {
        'delete_form': delete_form,
    }
    return render(request, 'promotion/delete.html',context)
def update_promotion(request,pro_id):
    promotion = get_object_or_404(Promotion, id=pro_id)
    form = UpdatePro(instance=promotion)
    if request.method == 'POST':
        form = UpdatePro(request.POST, instance=promotion)
        print(request.POST)
        if form.is_valid():
            promotion.save()
            return redirect('promotion')
    ctx = {
        "form": form,
    }
    return render(request, 'promotion/update.html',ctx)

def afficher_promotion(request,pro_id):
    promotion = get_object_or_404(Promotion, id=pro_id)
    form = UpdatePro(instance=promotion)

    ctx = {
        "form":promotion,
    }
    return render(request, 'promotion/afficher.html',ctx)
