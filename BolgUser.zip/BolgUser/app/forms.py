from django import forms
from django.forms import NumberInput
from . import models
from .models import *

class AddPro(forms.ModelForm):
    class Meta():
        model = Promotion
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(AddPro, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class': "form-control"})

class DeletePro(forms.Form):
    delete_pro = forms.BooleanField(widget=forms.HiddenInput, initial=True)

class UpdatePro(forms.ModelForm):
    edit_promotion = forms.BooleanField(widget=forms.HiddenInput, initial=True)

    class Meta():
        model = Promotion
        fields = '__all__'


    def __init__(self, *args, **kwargs):
        super(UpdatePro, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'
