from django.contrib import admin

from app.models import Promotion

# Register your models here.
admin.site.register(Promotion)
