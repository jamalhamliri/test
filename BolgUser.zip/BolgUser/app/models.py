from django.db import models

from BolgUser import settings
from authentication.models import User


class Promotion(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Eleve(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    image = models.ImageField(verbose_name='Photo de profil', upload_to=settings.MEDIA_ROOT / 'eleve', blank=True)
    promotion = models.ForeignKey(Promotion, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.nom} {self.prenom}"

    def get_full(self):
        return f"{self.nom} {self.prenom}"

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url


class Consigne(models.Model):
    eleve = models.ForeignKey(Eleve, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    consigne_motif=models.CharField(max_length=100,blank=True)
    date_debut = models.DateField()
    date_fin = models.DateField()
    def __str__(self):
        return f"{self.eleve}"


class Arret(models.Model):
    eleve = models.ForeignKey(Eleve, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    arret_motif = models.CharField(max_length=100,blank=True)
    nombre_jour = models.IntegerField(null=True)
    date_debut = models.DateField()
    date_fin = models.DateField()
    def __str__(self):
        return f"{self.eleve}"
