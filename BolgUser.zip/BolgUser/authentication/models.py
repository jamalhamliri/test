import datetime

from django.contrib.auth.base_user import AbstractBaseUser
from django.contrib.auth.models import AbstractUser, Group
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from BolgUser import settings



class User(AbstractUser):

    grade = models.CharField(max_length=50, blank=True)
    role = models.CharField(max_length=30, verbose_name='rôle', blank=True)

    image = models.ImageField(verbose_name='Photo de profil',upload_to=settings.MEDIA_ROOT / 'user', blank=True)
    address = models.CharField(max_length=250, blank=True)

    phone = models.CharField(max_length=14, blank=True,
                             null=True)  # you can set it unique = True
    date_of_birth = models.DateField(_("Date de naissance"), default=datetime.date.today)
    date_joined = models.DateTimeField(default=timezone.now)

